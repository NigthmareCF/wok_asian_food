# Base de datos y ERD — WOK Asian Food

Revisión del 2026-09-17. **Diseño candidato recuperado y regenerado; no base de datos implementada ni esquema aprobado para producción.**

La nueva lectura del disco externo fue satisfactoria. Se recuperaron completos el modelo, generador, SQL, diccionario, contratos de integridad, diagramas y los tres documentos funcionales originales. Se conservaron copias locales con hashes para que la próxima revisión no dependa del disco externo.

## Archivos para el equipo

**Antes de cerrar el ERD:** revisar el [desglose funcional completo](FUNCTIONAL_SCOPE.md) y la [matriz de 529 requisitos](REQUIREMENTS_REVIEW.csv). Cubren el inventario de las 21 épicas y separan comportamiento documentado, decisiones pendientes y evidencia de implementación aún por verificar.

| Archivo                                                                                   | Utilidad                                                                                  |
| ----------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| [ERD completo editable](erd/wok-complete-erd.drawio)                                      | 109 tablas; 17 páginas: vista general, 14 dominios, correspondencia legacy y ERD completo |
| [Índice por dominio](erd/README.md)                                                       | 14 archivos Mermaid con columnas y relaciones físicas                                     |
| [Facturación editable](erd/invoicing-focus.drawio) y [vista SVG](erd/invoicing-focus.svg) | Vista parcial de pedido, cuenta, factura, nota de crédito y cobro                         |
| [SQL PostgreSQL 18](../../database/schema/postgresql.sql)                                 | DDL declarativo recuperado, sin ejecución ni migración incremental                        |
| [Diccionario de datos](data-dictionary.md)                                                | Columnas, tipos, nulabilidad, claves, CHECK e índices                                     |
| [Contratos de integridad](design-decisions.md)                                            | R01–R13 del diseño original: transacciones, conservación y reglas entre entidades         |
| [Correspondencia con backend Spring](BACKEND_MAPPING.md)                                  | Propiedad de tablas, casos de uso, orden de adopción y precauciones JPA                   |
| [Hallazgos y decisiones pendientes](REVIEW_FINDINGS.md)                                   | Brechas que impiden declarar cerrado el diseño                                            |
| [Validación](VALIDATION.md) y [resultado estructurado](VALIDATION.json)                   | Alcance y resultados comprobados en esta revisión                                         |
| [Manifiesto de fuentes](SOURCE_MANIFEST.json)                                             | Procedencia lógica, tamaños y SHA-256 de las copias recuperadas                           |

Abrir el archivo `.drawio` con diagrams.net/Draw.io. Empezar por la página del dominio que se va a implementar. La vista general sirve para localizar entidades; el detalle de 109 tablas requiere zoom. El SVG de facturación se abre en navegador y puede enviarse independientemente.

## Qué se verificó

- 109 tablas, 1,153 columnas, 306 FK simples y una FK compuesta contextual.
- 181 índices explícitos; adicionalmente PostgreSQL crea índices asociados a PK/UNIQUE.
- 17 páginas reales del Draw.io. El informe externo antiguo hablaba de 16; el archivo actual añade `16 - ERD Completo`.
- Modelo, DDL, diccionario y XML coinciden en los controles estructurales ejecutados.
- Las copias regeneradas del modelo original coinciden byte a byte con los hashes recuperados.
- Fuentes originales completas: 21 épicas, 308 historias, RN-001–145 y RT-001–076.

Contar requisitos no acredita su cobertura. No se ejecutó PostgreSQL, no se instalaron dependencias, no se generaron entidades Java ni se conectó un proveedor fiscal. La revisión del ERD completo es estructural; se renderizó e inspeccionó visualmente el nuevo foco de facturación.

## Aclaración sobre facturación

**Facturación ya estaba prevista en el diseño externo de datos:** existen `invoices` e `invoice_items`. La nota de crédito usa `invoices.document_type = CREDIT_NOTE` y referencia el documento original. `bills` representa cuentas de consumo, `payments` cobros y `payment_receipts` comprobantes de pago; ninguno sustituye una factura.

Esto precisa la revisión anterior: no se encontró módulo frontend de emisión ni tarea completa de backend en el plan; no significa que faltaran las entidades en el ERD externo. Este paquete las hace visibles, pero no aprueba una integración fiscal ni extiende silenciosamente el plazo del proyecto.

Pendiente con PM/ingeniero: facturación académica o emisión fiscal real, proveedor si aplica, estados de emisión, numeración, impuestos comerciales, documentos correctivos y alcance de pantallas. No se establecen aquí obligaciones tributarias ni formatos legales.

## Fuentes funcionales completas

- [Épicas e historias](requirements/epics-and-user-stories.txt).
- [Reglas de negocio y requisitos técnicos](requirements/business-rules-and-requirements.txt).
- [Vistas y mockups textuales](requirements/views-and-mockups.txt).
- [Correspondencia del modelo preliminar](erd/legacy-mapping.md).

Los TXT se renombraron al inglés para las rutas técnicas, sin alterar su contenido. El diseño externo proviene de la documentación académica de Desarrollo Web suministrada como contexto. Los planes [backend](../backend/DEVELOPMENT_PLAN.md) y [app Cliente](../mobile/CLIENT_APP_PLAN.md) definen un corte de entrega menor que todo el modelo; no debe confundirse diseño objetivo con compromiso de implementar 109 tablas en pocas semanas.

## Regeneración y validación local

Desde la raíz del repositorio, con Python estándar:

```bash
python3 database/design/generate.py
python3 database/design/generate_views.py
python3 database/design/validate.py
```

El primer comando regenera los artefactos originales desde su fuente declarativa; el segundo crea vistas derivadas; el tercero valida estructura sin conectar a DB. **No editar directamente el JSON/SQL generado:** revisar el generador, registrar decisión y regenerar en conjunto. El manifiesto captura la base recuperada; tras cambios de diseño intencionales, su comparación señalará divergencia hasta registrar una nueva revisión de procedencia.

Para implementar: resolver hallazgos, convertir el corte aprobado en migraciones Flyway, ejecutar sobre PostgreSQL desechable y probar transacciones reales. El SQL actual crea esquema/tablas de una vez y falla si ya existen; no aplicarlo sobre una DB de trabajo con datos. Respetar la advertencia del artefacto original de no ejecutarlo directamente en servidores.
