# Validación del ERD recuperado y vistas derivadas

Fecha: 2026-09-17. Resultado: **PASS_STATIC**. Detalle reproducible en [VALIDATION.json](VALIDATION.json).

## Comprobaciones realizadas

- Lectura completa de diez archivos fuente y registro de SHA-256. Sin errores de E/S en esta recuperación.
- Regeneración local mediante el generador original; modelo, SQL, diccionario, mapeo legacy y ERD resultantes coinciden con las fuentes recuperadas.
- 109 tablas y 1,153 columnas concordantes entre modelo/SQL; tipos, nulabilidad, defaults, CHECK, UNIQUE e índices contrastados mediante controles estructurales.
- 306 referencias FK simples a tablas existentes y una compuesta contextual; políticas RESTRICT conservadas.
- 181 índices explícitos y exclusión de solape en asignaciones de reserva.
- Draw.io: 17 páginas coincidentes con el modelo, IDs únicos por página, referencias de aristas existentes, columnas visibles en XML y ausencia de solapes entre cajas de entidades locales.
- Regeneración de 14 diagramas Mermaid y foco de facturación editable/SVG.
- Foco SVG renderizado e inspeccionado visualmente; representa relaciones principales y omite explícitamente columnas/FK externas.
- Conteo de fuentes: 21 épicas, 308 historias, 145 RN y 76 RT.

## Qué no se verificó

- No se ejecutó SQL en PostgreSQL ni se creó una base real.
- El parser SQL opcional `pglast` no está disponible en este entorno; la validación por patrones/modelo no sustituye un parser completo ni el motor.
- No se probaron transacciones concurrentes, migraciones Flyway, mapeos JPA, emisión de facturas o proveedores.
- No se renderizaron visualmente las 17 páginas del ERD completo ni los 14 Mermaid; sus controles son estructurales. Páginas densas pueden necesitar ajuste manual de conectores.
- El conteo de requisitos no certifica cobertura funcional. Ver [hallazgos](REVIEW_FINDINGS.md).

## Comandos

```bash
python3 database/design/generate.py
python3 database/design/generate_views.py
python3 database/design/validate.py
```

El validador no instala paquetes, ejecuta SQL ni abre conexiones. Si en una revisión futura se dispone de `pglast`, añade análisis sintáctico y lo informa expresamente; sigue sin demostrar ejecución o integridad de aplicación.

La aceptación de la DB requiere una fase posterior sobre PostgreSQL desechable: creación desde cero, FK/CHECK, concurrencia del último recurso, no solape de reservas, pago idempotente, conservación histórica, suma de líneas, corrección de factura y restauración. Se debe usar el corte de alcance aprobado y resolver antes las diferencias con el contrato API.
